<?php
/*
*       ___        __  _     ___                
* __ __/ __| ___  / _|| |_  / __| ___  _ _  ___ 
* \ \ /\__ \/ _ \|  _||  _|| (__ / _ \| '_|/ -_)
* /_\_\|___/\___/|_|   \__| \___|\___/|_|  \___|
* 
* Этот софт является бесплатным! Но любое его распространение без указания автора карается баном на официальной странице xSoftCore на GitHub!
* 
* @github: https://github.com/dixsin/softcore
* @author: https://vk.com/dixsin
* @releases: https://github.com/dixsin/softcore/releases
*/

namespace pocketmine\command\defaults;

use pocketmine\command\CommandSender;
use pocketmine\event\TranslationContainer;
use pocketmine\level\Level;
use pocketmine\level\weather\Weather;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class BcCommand extends VanillaCommand {
	public function __construct($name){
		parent::__construct(
			$name,
			["broadcast", "say"]
		);
		$this->setPermission("bc.use");
	}
	public function execute(CommandSender $sender, $currentAlias, array $args){
		if(!$this->testPermission($sender)){
			return true;
		}
		if(count($args) < 1){
			$sender->sendMessage("§7§l[§6xSoftCore§7] §fИспользуйте /bc (СООБЩЕНИЕ)");
		} else {
		      $server = $sender->getServer();
		      $message = implode(" ", $args);
		      $server->broadcastMessage("§6§lВНИМАНИЕ! §r§fПишет игрок §l§6". $sender->getName() ."§r§f: §l§6". $message ."!");
		}
	}
}
