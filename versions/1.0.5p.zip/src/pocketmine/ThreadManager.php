<?php
/*
*       ___        __  _     ___                
* __ __/ __| ___  / _|| |_  / __| ___  _ _  ___ 
* \ \ /\__ \/ _ \|  _||  _|| (__ / _ \| '_|/ -_)
* /_\_\|___/\___/|_|   \__| \___|\___/|_|  \___|
* 
* Этот софт является бесплатным! Но любое его распространение без указания автора карается баном на официальной странице xSoftCore на GitHub!
* 
* @github: https://github.com/dixsin/softcore
* @author: https://vk.com/dixsin
* @releases: https://github.com/dixsin/softcore/releases
*/

namespace pocketmine;

use pocketmine\utils\MainLogger;

class ThreadManager extends \Volatile {

	/** @var ThreadManager */
	private static $instance = null;

	public static function init(){
		self::$instance = new ThreadManager();
	}

	/**
	 * @return ThreadManager
	 */
	public static function getInstance(){
		return self::$instance;
	}

	/**
	 * @param Worker|Thread $thread
	 */
	public function add($thread){
		if($thread instanceof Thread or $thread instanceof Worker){
			$this->{spl_object_hash($thread)} = $thread;
		}
	}

	/**
	 * @param Worker|Thread $thread
	 */
	public function remove($thread){
		if($thread instanceof Thread or $thread instanceof Worker){
			unset($this->{spl_object_hash($thread)});
		}
	}

	/**
	 * @return Worker[]|Thread[]
	 */
	public function getAll() : array{
		$array = [];
		foreach($this as $key => $thread){
			$array[$key] = $thread;
		}

		return $array;
	}

	public function stopAll() : int{
		$logger = MainLogger::getLogger();

		$erroredThreads = 0;

		foreach($this->getAll() as $thread){
			$logger->debug("Stopping " . $thread->getThreadName() . " thread");
			try{
				$thread->quit();
				$logger->debug($thread->getThreadName() . " thread stopped successfully.");
			}catch(\ThreadException $e){
				++$erroredThreads;
				$logger->debug("Could not stop " . $thread->getThreadName() . " thread: " . $e->getMessage());
			}
		}

		return $erroredThreads;
	}
}