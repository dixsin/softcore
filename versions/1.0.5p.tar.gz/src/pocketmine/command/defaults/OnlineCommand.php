<?php
/*
*       ___        __  _     ___                
* __ __/ __| ___  / _|| |_  / __| ___  _ _  ___ 
* \ \ /\__ \/ _ \|  _||  _|| (__ / _ \| '_|/ -_)
* /_\_\|___/\___/|_|   \__| \___|\___/|_|  \___|
* 
* Этот софт является бесплатным! Но любое его распространение без указания автора карается баном на официальной странице xSoftCore на GitHub!
* 
* @github: https://github.com/dixsin/softcore
* @author: https://vk.com/dixsin
* @releases: https://github.com/dixsin/softcore/releases
*/

namespace pocketmine\command\defaults;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Utils;

class OnlineCommand extends VanillaCommand {

	/**
	 * StatusCommand constructor.
	 *
	 * @param $name
	 */
	public function __construct($name){
		parent::__construct($name);
		$this->setPermission("online.use");
	}

	/**
	 * @param CommandSender $sender
	 * @param string        $currentAlias
	 * @param array         $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, $currentAlias, array $args){
		if(!$this->testPermission($sender)){
			return true;
		}
		$server = $sender->getServer();
		$arr = [
		    "online" => count($server->getOnlinePlayers()),
		    "maxonline" => $server->getMaxPlayers()
		];
		    $muse = Utils::getRealMemoryUsage();
		    $sender->sendMessage("§7§l[§6xSoftCore§7] §fИгроки онлайн:");
		    $sender->sendMessage("§7§l[§6xSoftCore§7] §f(". $arr["online"] ." / ". $arr["maxonline"] .")");
		    $sender->sendMessage("§7§l[§6xSoftCore§7] §f ТPS сервера ". $server->getTPS() ." TPS");
		    $sender->sendMessage("§7§l[§6xSoftCore§7] §f Нагрузка сервера Проценты (". $server->getTickUsage() ."% / 100%)");
		}
}
