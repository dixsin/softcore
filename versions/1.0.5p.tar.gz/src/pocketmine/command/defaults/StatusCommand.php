<?php
/*
*       ___        __  _     ___                
* __ __/ __| ___  / _|| |_  / __| ___  _ _  ___ 
* \ \ /\__ \/ _ \|  _||  _|| (__ / _ \| '_|/ -_)
* /_\_\|___/\___/|_|   \__| \___|\___/|_|  \___|
* 
* Этот софт является бесплатным! Но любое его распространение без указания автора карается баном на официальной странице xSoftCore на GitHub!
* 
* @github: https://github.com/dixsin/softcore
* @author: https://vk.com/dixsin
* @releases: https://github.com/dixsin/softcore/releases
*/

namespace pocketmine\command\defaults;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Utils;

class StatusCommand extends VanillaCommand {

	/**
	 * StatusCommand constructor.
	 *
	 * @param $name
	 */
	public function __construct($name){
		parent::__construct(
			$name,
			"%pocketmine.command.status.description",
			"%pocketmine.command.status.usage"
		);
		$this->setPermission("pocketmine.command.status");
	}

	/**
	 * @param CommandSender $sender
	 * @param string        $currentAlias
	 * @param array         $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, $currentAlias, array $args){
		if(!$this->testPermission($sender)){
			return true;
		}

		$rUsage = Utils::getRealMemoryUsage();
		$mUsage = Utils::getMemoryUsage(true);

		$server = $sender->getServer();
		$sender->sendMessage("§7§l[§6xSoftCore§7] §fСтатус сервера");
		$sender->sendMessage("§7§l[§6xSoftCore§7] §f%pocketmine.command.status.CurrentTPS ". $server->getTicksPerSecond() . " §e(§6" . $server->getTickUsage() . "%§e)");
		$sender->sendMessage("§7§l[§6xSoftCore§7] §f%pocketmine.command.status.AverageTPS ". $server->getTicksPerSecondAverage() . " §e(§6" . $server->getTickUsageAverage() . "%§e)");

		$onlineCount = 0;
		foreach($sender->getServer()->getOnlinePlayers() as $player){
			if($player->isOnline() and (!($sender instanceof Player) or $sender->canSee($player))){
				++$onlineCount;
			}
		}
		foreach($server->getLevels() as $level){
			$levelName = $level->getFolderName() !== $level->getName() ? " (" . $level->getName() . ")" : "";
			$sender->sendMessage("§7§l[§6xSoftCore§7] §fМир \"{$level->getFolderName()}\"$levelName: " .
				TextFormat::WHITE . number_format(count($level->getChunks())) . TextFormat::WHITE . " %pocketmine.command.status.chunks " .
				TextFormat::WHITE . number_format(count($level->getEntities())) . TextFormat::WHITE . " %pocketmine.command.status.entities " .
				TextFormat::WHITE . number_format(count($level->getTiles())) . TextFormat::WHITE . " %pocketmine.command.status.tiles " .
				"%pocketmine.command.status.Time " . round($level->getTickRateTime(), 2) . "ms"
			);
		}

		return true;
	}
}
