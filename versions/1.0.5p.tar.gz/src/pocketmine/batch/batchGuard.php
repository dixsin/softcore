<?php
/*
*       ___        __  _     ___                
* __ __/ __| ___  / _|| |_  / __| ___  _ _  ___ 
* \ \ /\__ \/ _ \|  _||  _|| (__ / _ \| '_|/ -_)
* /_\_\|___/\___/|_|   \__| \___|\___/|_|  \___|
* 
* Этот софт является бесплатным! Но любое его распространение без указания автора карается баном на официальной странице xSoftCore на GitHub!
* 
* @github: https://github.com/dixsin/softcore
* @author: https://vk.com/dixsin
* @releases: https://github.com/dixsin/softcore/releases
*/

namespace pocketmine\batch;

use pocketmine\Server;
use pocketmine\Player;

class batchGuard extends Server, Player{

	/* @var private */
	private $UUID = 3;
	private $maxPackets = 10;
	private $text = 300;

	/* @var batchGuard constructor */
	public function __construct(){}

	/* @function onFlood */
	public function onFlood(){
		$this->getPluginManager()->callEvent($ev = new PlayerPreLoginEvent($this, "Limit UUID Packets"));
		if($ev->getPlayer()->getUniqueId() < self::UUID) {
			$ev->getPlayer()->close("Привет пошел нахуй");
		}
	}

	/* @function onPing */
	public function onPing(){
		$this->getPluginManager()->callEvent($ev = new PlayerPreLoginEvent($this, "Limit BATCH Packets"));
		if($ev->getPlayer()->getPing() < self::maxPackets){
			$ev->getPlayer()->close("Привет пошел нахуй");
		}
	}

	/* @function onText */
	public function onText(){
		$this->getPluginManager()->callEvent($ev = new PlayerChatEvent($this, "Limit TEXT Packets"));
		$player = $ev->getPlayer();
		$s = ["\n"];
		$message = $ev->getMessage();
		foreach ($s as $symbols) {
			$pos = strpos(mb_strtolower($message), $symbols);
			if (!$pos == false) {
				$ev->close("Привет пошел нахуй");
			}
		}
	}
}
